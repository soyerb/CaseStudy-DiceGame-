package org.example;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numRounds;
        do {
            System.out.print("Enter Number of Rounds (1-99): ");
            numRounds = scanner.nextInt();
        } while (numRounds < 1 || numRounds > 99);

        int player1Total = 0;
        int player2Total = 0;
        int player3Total = 0;

        for (int round = 1; round <= numRounds; round++) {
            System.out.println("\nROUND " + round);

            int dice1 = rollDice();
            int dice2 = rollDice();
            int dice3 = rollDice();

            System.out.println("DICE1\t\tDICE2\t\tDICE3\t\tTOTAL1\t\tTOTAL2\t\tTOTAL3");
            System.out.println(dice1 + "\t\t" + dice2 + "\t\t" + dice3 + "\t\t" + player1Total + "\t\t" + player2Total + "\t\t" + player3Total);

            if (dice1 == dice2 && dice2 == dice3) {
                player1Total += dice1;
                player2Total += dice2;
                player3Total += dice3;
            } else if (dice1 == dice2 || dice2 == dice3 || dice1 == dice3) {
                int sameDiceValue = Math.max(dice1, Math.max(dice2, dice3));
                if (dice1 == sameDiceValue) {
                    player1Total += sameDiceValue * 2;
                }
                if (dice2 == sameDiceValue) {
                    player2Total += sameDiceValue * 2;
                }
                if (dice3 == sameDiceValue) {
                    player3Total += sameDiceValue * 2;
                }
            } else {
                player1Total += dice1;
                player2Total += dice2;
                player3Total += dice3;
            }
        }

        System.out.println("\nFinal Scores:");
        System.out.println("Player 1: " + player1Total);
        System.out.println("Player 2: " + player2Total);
        System.out.println("Player 3: " + player3Total);
    }

    public static int rollDice() {
        return (int) (Math.random() * 6) + 1;
    }
}
